<link rel="stylesheet" href="http://localhost/eshop/assets/front_end/classic/css/style.css">
<main>
    <section class="container page_404 py-4">
        <div class="text-center">
            <div class="four_zero_four_bg">
                <h1 class="section-title text-center">404</h1>
            </div>
            <div class="contant_box_404">
                <h3 class="section-title">Look like you're lost</h3>
                <p class="text-body-secondary">the page you are looking for not avaible!</p>
                <!-- <a href="" class="link_404">Go to Home</a> -->
                <a href="#" onclick="history.back(-1)" class="btn btn-primary link_404">Go Back</a>
            </div>
        </div>
    </section>
</main>