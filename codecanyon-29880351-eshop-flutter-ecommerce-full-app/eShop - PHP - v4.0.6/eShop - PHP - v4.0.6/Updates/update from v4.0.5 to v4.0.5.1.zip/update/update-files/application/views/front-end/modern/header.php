<?php $current_url = current_url(); ?>
<?php
$this->load->model('category_model');
$categories = $this->category_model->get_categories(null, 8);
$language = get_languages();
$cookie_lang = $this->input->cookie('language', TRUE);
$web_settings = get_settings('web_settings', true);
?>
<!-- Navbar in >=1200px -->
<input type="hidden" id="baseUrl" value="<?= base_url() ?>">
<div class="bg-white top-nav">
    <div class="container d-none d-xl-block d-xxl-block">
        <nav class="navbar navbar-expand-xl navbar-light bg-white ">
            <?php $logo = get_settings('web_logo'); ?>
            <a class="company-logo" href="<?= base_url() ?>">
                    <?php $logo = get_settings('web_logo'); ?>
                    <img src="<?= base_url($logo) ?>" data-src="<?= base_url($logo) ?>" class="me-3v pointer brand-logo-link">
            </a>
            <form class="d-flex searchcontainer mx-5 searchbar">
                <!-- <input class="form-control me-2 searchbar" type="text" placeholder="Search for Product" aria-label="Search" required>
                <button class="searchicon" type="submit">
                    <i class="ionicon-search-outline"></i>
                </button> -->
                <select class="form-control me-2 search_product" type="text" aria-label="Search">search</select>
            </form>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse fw-semibold " id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 justify-content-around width100 white-space-nowrap">
                    <li class="nav-item">
                        <a class="nav-link font-color" title="Support" aria-current="page" href="<?= base_url('home/contact-us') ?>"><?= label('Support', 'Support') ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link font-color" title="About Us" href="<?= base_url('home/about-us') ?>"><?= label('about_us', 'About Us') ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link font-color" title="FAQs" href="<?= base_url('home/faq') ?>"><?= label('faq', 'FAQs') ?></a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>
<header class="d-none d-xl-block d-xxl-block search-nav">
    <div class="nav-outer bg-nav">
        <div class="container d-none d-xl-flex d-xxl-flex justify-content-between align-items-center">
            <ul class="navbar-nav flexrow white-space-nowrap">
                <li class="nav-category pointer <?= ($current_url == base_url()) ? ' active-nav' : '' ?>">
                    <a href="<?= base_url() ?>">
                        <span title="Home"><?= label('home', 'Home') ?></span>
                    </a>
                </li>
                <li class="nav-category pointer <?= ($current_url == base_url('home/categories')) ? ' active-nav' : '' ?>" title="All Categories">
                    <a href="<?= base_url('home/categories') ?>">
                        <span><?= label('category', 'All Categories') ?></span>
                    </a>
                </li>
                <li class="nav-category pointer <?= ($current_url == base_url('products')) ? ' active-nav' : '' ?>">
                    <a href="<?= base_url('products') ?>">
                        <span title="Products"><?= label("products", "Products") ?></span>
                    </a>
                </li>
                <li class="nav-category pointer <?= ($current_url == base_url('products/offers_and_flash_sale')) ? ' active-nav' : '' ?>">
                    <a href="<?= base_url('products/offers_and_flash_sale') ?>">
                        <span title="Top Offers"><?= label('Top Offers', 'Top Offers') ?></span>
                    </a>
                </li>
                <li class="nav-category pointer <?= ($current_url == base_url('home/contact-us')) ? ' active-nav' : '' ?>">
                    <a href="<?= base_url('home/contact-us') ?>">
                        <span title="Contact us"><?= label('contact_us', 'Contact us') ?></span>
                    </a>
                </li>
                <li class="nav-category pointer <?= ($current_url == base_url('home/about-us')) ? ' active-nav' : '' ?>">
                    <a href="<?= base_url('home/about-us') ?>">
                        <span title="About us"><?= label('about_us', 'About us') ?></span>
                    </a>
                </li>
            </ul>
            <div class="d-flex">
                <div class="btn-group">
                    <a href="javascript:void(0);" class="btn btn-none btn-sm fw-semibold dropdown-toggle align-self-center" title="Language" type="button" data-bs-toggle="dropdown" aria-expanded="false"><span><?= label('language', ('Language')) ?></span></a>
                    <ul class="dropdown-menu pointer">
                        <?php foreach ($language as $row) { ?>
                            <li class="dropdown-item"><a href="<?= base_url('home/lang/' . strtolower($row['language'])) ?>"><?= strtoupper($row['code']) . ' - ' . ucfirst($row['language']) ?></a></li>
                        <?php } ?>
                    </ul>
                </div>
                <ul class="d-flex align-items-center margin0 list-style">
                    <a href="<?= base_url('compare') ?>">
                        <li class="shopingicon mx-2 pointer" title="compare">
                            <i class="ionicon-compare-outline bghover transition-d-025"></i>
                        </li>
                    </a>
                    <?php $page = $this->uri->segment(2) == 'checkout' ? 'checkout' : '' ?>
                    <?php if ($page == 'checkout') { ?>
                        <li class="shopingicon mx-2 pointer" title="Cart" data-bs-toggle="offcanvas" data-bs-target="#cartmodal" aria-controls="offcanvasRight">
                            <a href="<?= base_url('cart') ?>" class="d-block">
                                <i class="ionicon-bag-handle-outline bghover transition-d-025" 0></i>
                                <span class="badge badge-danger badge-sm cart-count" id='cart-count'><?= (count($this->cart_model->get_user_cart($this->session->userdata('user_id'))) != 0 ? count($this->cart_model->get_user_cart($this->session->userdata('user_id'))) : ''); ?></span>
                            </a>
                        </li>
                    <?php } else { ?>
                        <li class="shopingicon mx-2 pointer" title="Cart" data-bs-toggle="offcanvas" data-bs-target="#cartmodal" aria-controls="offcanvasRight">
                            <a href="javascript:void(0);" class="d-block">
                                <i class="ionicon-bag-handle-outline bghover transition-d-025" 0></i>
                                <span class="badge badge-danger badge-sm cart-count" id='cart-count'><?= (count($this->cart_model->get_user_cart($this->session->userdata('user_id'))) != 0 ? count($this->cart_model->get_user_cart($this->session->userdata('user_id'))) : ''); ?></span>
                            </a>
                        </li>
                    <?php } ?>
                    <!-- <li class="shopingicon mx-2 pointer" title="Cart" data-bs-toggle="offcanvas" data-bs-target="#cartmodal" aria-controls="offcanvasRight">
                        <i class="ionicon-bag-handle bghover transition-d-025" 0></i>
                    </li> -->
                    <a href="<?= base_url('my-account/favorites') ?>">
                        <li class="shopingicon mx-2 pointer" title="Like Product">
                            <i class="ionicon-heart bghover transition-d-025"></i>
                        </li>
                    </a>
                    <?php if ($this->ion_auth->logged_in()) { ?>
                        <a href="<?= base_url('my-account') ?>">
                            <li class="shopingicon mx-2 pointer" title="Profile">
                                <i class="ionicon-person bghover transition-d-025"></i>
                            </li>
                        </a>
                    <?php } else { ?>
                        <a data-bs-toggle="offcanvas" data-bs-target="#login-canvas" aria-controls="offcanvasRight">
                            <li class="shopingicon mx-2 pointer" title="Sign up">
                                <i class="ionicon-person bghover transition-d-025"></i>
                            </li>
                        </a>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </div>

    <form class="d-xl-none d-xxl-none searchcontainer">
        <input class="form-control searchbar" type="text" placeholder="Search for Product" aria-label="Search" required>
        <button class="searchicon" type="submit">
            <i class="ionicon-search-outline"></i>
        </button>
    </form>
</header>
<!--Navbar in <= 1200px -->

<header class="search-nav">
    <nav class="navbar navbar-md d-xl-none d-xxl-none">
        <button class="btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
            <i class="fa fa-navicon text-dark-emphasis"></i>
        </button>

        <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title d-flex align-items-center" id="offcanvasExampleLabel">
                    <ion-icon name="person-outline" class="menu-icon"></ion-icon>
                    <?php if ($this->ion_auth->logged_in()) { ?>
                        <a href="<?= base_url('my_account') ?>">
                            <?= label('Hello', 'Hello') ?> <?= $user->username ?>
                        </a>
                    <?php } else { ?>
                        <a href="<?= base_url('register') ?>">
                            <?= label('login', 'Login') ?>/<?= label('register', 'Register') ?>
                        </a>
                    <?php } ?>
                </h5>
                <button type="button" class="btn text-reset" data-bs-dismiss="offcanvas" aria-label="Close">
                    <ion-icon name="chevron-forward-outline"></ion-icon>
                </button>
            </div>
            <div class="offcanvas-body py-0">
                <ul class="list-unstyled">
                    <li>
                        <a href="<?= base_url('home/categories/') ?>">
                            <ion-icon name="cube-outline" class="menu-icon"></ion-icon><span class="text-body-emphasis">
                                <?= label('category', 'Categories') ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('products') ?>">
                            <ion-icon name="storefront-outline" class=" menu-icon"></ion-icon><span class="text-body-emphasis"><?= label('products', 'Products') ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('my-account/orders') ?>">
                            <ion-icon name="timer-outline" class="menu-icon"></ion-icon><span class="text-body-emphasis"><?= label('my_orders', 'My Orders') ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('my-account/favorites') ?>">
                            <ion-icon name="heart-outline" class="menu-icon"></ion-icon><span class="text-body-emphasis"><?= label('favorite', 'Favarites') ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('home/about-us') ?>">
                            <ion-icon name="information-circle-outline" class="menu-icon"></ion-icon><span class="text-body-emphasis"><?= label('about_us', 'About Us') ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('home/contact-us') ?>">
                            <ion-icon name="mail-outline" class="menu-icon"></ion-icon><span class="text-body-emphasis"><?= label('contact_us', 'Contact Us') ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('home/faq') ?>">
                            <ion-icon name="help-circle-outline" class="menu-icon"></ion-icon><span class="text-body-emphasis"><?= label('faq', 'FAQs') ?></span>
                        </a>
                    </li>
                    <li class="d-flex align-items-center language-box">
                        <ion-icon name="language-outline" class="menu-icon"></ion-icon><span class="text-body-emphasis">
                            <div class="dropdown">
                                <a href="javascript:void(0);" class="btn btn-none btn-sm fw-semibold dropdown-toggle align-self-center" title="Language" type="button" data-bs-toggle="dropdown" aria-expanded="false"><span><?= label('language', ('Language')) ?></span></a>
                                <ul class="dropdown-menu pointer">
                                    <?php foreach ($language as $row) { ?>
                                        <li class="dropdown-item"><a href="<?= base_url('home/lang/' . strtolower($row['language'])) ?>"><?= strtoupper($row['code']) . ' - ' . ucfirst($row['language']) ?></a></li>
                                    <?php } ?>
                                </ul>
                            </div>
                        </span>
                    </li>
                </ul>
            </div>
        </div>
        <a href="<?= base_url() ?> ">
            <img class="company-logo me-3v pointer" src="<?= base_url("assets/front_end/modern/image/eshop-vendor-logo.png") ?>" alt="">
            <!-- <img class="company-logo me-3v pointer" src="<?= base_url($logo) ?>" data-src="<?= base_url($logo) ?> -->
        </a>
        <ul class=" d-flex list-unstyled align-items-center fw-bold m-0">
            <li class="me-3 pointer color-primary" data-bs-toggle="offcanvas" data-bs-target="#cartmodal" aria-controls="offcanvasRight">
                <i class="ionicon-cart-outline"></i>
            </li>
            <li class="color-primary">
                <a href="<?= base_url('register_login_page.php') ?>">
                    <?php if ($this->ion_auth->logged_in()) { ?>
                        <a href="<?= base_url('my-account') ?>">
                            <i class="ionicon-person-outline"></i>
                        </a>
                    <?php } else { ?>
                        <a data-bs-toggle="offcanvas" data-bs-target="#login-canvas" aria-controls="offcanvasRight">
                            <i class="ionicon-person-outline"></i>
                        </a>
                    <?php } ?>
                </a>
            </li>
        </ul>
    </nav>
</header>
<div class="container-fluid p-0">
    <form class="d-xl-none d-xxl-none searchcontainer">
        <!-- <input class="form-control searchbar" type="text" placeholder="Search for Product" aria-label="Search" required>
        <button class="searchicon" type="submit">
            <i class="ionicon-search-outline"></i>
        </button> -->
        <select class="form-control me-2 search_product" type="text" aria-label="Search">search</select>
    </form>
</div>