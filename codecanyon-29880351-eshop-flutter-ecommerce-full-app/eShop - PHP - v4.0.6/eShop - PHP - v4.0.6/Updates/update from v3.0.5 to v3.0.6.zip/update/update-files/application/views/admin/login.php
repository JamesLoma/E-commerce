<!DOCTYPE html>
<html>
<?php $this->load->view('admin/include-head.php'); ?>

<body class="hold-transition login-page ">
    <?php $this->load->view('admin/pages/' . $main_page); ?>
    <!-- Footer -->
    <?php $this->load->view('admin/include-script.php'); ?>
</body>

</html>