<div class="liner-continer">
    <h4>TODAY HOT DEALS</h4>
</div>